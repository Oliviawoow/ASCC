/*
 * Tema 2 ASC
 * 2021 Spring
 */
#include "utils.h"

/*
 * Add your optimized implementation here
 */
double* my_solver(int N, double *A, double* B) {
	register int size = N * N * sizeof(double);

	double *AB = (double *)malloc(size);
	double *ABB_t = (double *)malloc(size);

	/* A x B */
	for (register int i = 0; i != N; ++i)
		for (register int j = 0; j != N; ++j) {
			double *ptrA = &(A[i * N + i]);
			register double suma = 0.0;
			for (register int k = i; k != N; ++k) {
				suma += *ptrA * B[k * N + j];
				ptrA++;
			}
			AB[i * N + j] = suma;
		}
			
	/* A x B x B_t */
	for (register int i = 0; i != N; ++i)
		for (register int j = 0; j != N; ++j) {
			double *ptrAB = &(AB[i * N]);
			register double suma = 0.0;
			for (register int k = 0; k != N; ++k) {
				suma += *ptrAB * B[j * N + k];
				ptrAB++;
			}
			ABB_t[i * N + j] = suma;
		}
			
	/* A_t x A */
	for (register int i = 0; i != N; ++i)
		for (register int j = i; j != N; ++j) {
			double *ptrA = &(A[j]);
			double *ptrA2 = &(A[i]);
			register double suma = 0.0;
			for (register int k = 0; k != N; ++k) {
				suma += *ptrA * *ptrA2;
				ptrA += N;
				ptrA2 += N;
			}
			AB[i * N + j] = suma;
			if (i != j)
				AB[j * N + i] = AB[i * N + j];
		}

	/* C = A x B x B_t + A_t x A */
	for (register int i = 0; i != N; ++i)
		for (register int j = 0; j != N; ++j)
			ABB_t[i * N + j] += AB[i * N + j];

	free(AB);

	printf("OPT SOLVER\n");
	return ABB_t;	
}
