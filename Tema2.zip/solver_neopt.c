/*
 * Tema 2 ASC
 * 2021 Spring
 */
#include "utils.h"

/*
 * Add your unoptimized implementation here
 */
double* my_solver(int N, double *A, double* B) {
	int i, j, k;

	double *C = (double *)calloc(N * N, sizeof(double));
	double *AB = (double *)calloc(N * N, sizeof(double));
	double *ABB_t = (double *)calloc(N * N, sizeof(double));
	double *A_tA = (double *)calloc(N * N, sizeof(double));

	/* A x B */
	for (i = 0; i < N; ++i)
		for (j = 0; j < N; ++j)
			for (k = i; k < N; ++k)
				AB[i * N + j] += A[i * N + k] * B[k * N + j];

	/* A x B x B_t */
	for (i = 0; i < N; ++i)
		for (j = 0; j < N; ++j)
			for (k = 0; k < N; ++k)
				ABB_t[i * N + j] += AB[i * N + k] * B[j * N + k];

	/* A_t x A */
	for (i = 0; i < N; ++i)
		for (j = i; j < N; ++j)
			for (k = 0; k < N; ++k) {
				A_tA[i * N + j] += A[k * N + j] * A[k * N + i];
				if (i != j)
					A_tA[j * N + i] = A_tA[i * N + j];
			}

	/* C = A x B x B_t + A_t x A */
	for (i = 0; i < N; ++i)
		for (j = 0; j < N; ++j)
			C[i * N + j] += ABB_t[i * N + j] + A_tA[i * N + j];

	free(AB);
	free(ABB_t);
	free(A_tA);

	printf("NEOPT SOLVER\n");
	return C;
}
