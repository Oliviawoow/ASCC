/*
 * Tema 2 ASC
 * 2021 Spring
 */
#include "utils.h"
#include <cblas.h>
#include <string.h>

/* 
 * Add your BLAS implementation here
 */
double* my_solver(int N, double *A, double *B) {
	int i;

	double *C = (double *)calloc(N * N, sizeof(double));
	double *AB = (double *)calloc(N * N, sizeof(double));
	double *A_tA = (double *)calloc(N * N, sizeof(double));
	double *unitate = (double *)calloc(N * N, sizeof(double));

	for (i = 0; i < N; ++i)
		unitate[i * N + i] = 1;

	/* AB = A x B */
	memcpy(AB, B, N * N * sizeof(double));
	cblas_dtrmm(CblasRowMajor, CblasLeft, CblasUpper, CblasNoTrans,
	CblasNonUnit, N, N, 1.0, A, N, AB, N);

	/* C = A x B x B_t */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasTrans, N, N, N, 1.0,
	AB, N, B, N, 0, C, N);

	/* A_tA = A_t x A */
	memcpy(A_tA, A, N * N * sizeof(double));
	cblas_dtrmm(CblasRowMajor, CblasLeft, CblasUpper, CblasTrans,
	CblasNonUnit, N, N, 1.0, A, N, A_tA, N);

	/* C = C + A_tA */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, N, N, N,
	1.0, C, N, unitate, N, 1.0, A_tA, N);
	
	free(AB);
	free(C);
	free (unitate);

	printf("BLAS SOLVER\n");
	return A_tA;
}
